﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XamarinFormsUiEnhancements
{
    public partial class Animation : ContentPage
    {
        public Animation()
        {
            InitializeComponent();
        }
    }
}
