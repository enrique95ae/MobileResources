
### Build Statuses ###

iOS: ![alt text](https://build.appcenter.ms/v0.1/apps/fdc42fcc-e58a-4fcd-af1d-5b13ec18d374/branches/master/badge "iOS Build Status")


