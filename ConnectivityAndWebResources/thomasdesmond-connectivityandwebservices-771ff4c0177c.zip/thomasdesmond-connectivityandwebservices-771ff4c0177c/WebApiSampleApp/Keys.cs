﻿using System;
namespace WebApiSampleApp
{
    public static class Keys
    {
        public const string WeatherKey = "YOUR OPEN WEATHER MAP API KEY GOES HERE";
    }
}
