# README #

Example app for Connectivity Plugin and basics for consuming REST web services

